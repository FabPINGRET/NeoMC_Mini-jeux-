# End — vague 2
summon minecraft:enderman 11.5 64 1811.5 {Tags:["mg.mob"],PersistenceRequired:1b}
summon minecraft:enderman -11.5 64 1811.5 {Tags:["mg.mob"],PersistenceRequired:1b}
summon minecraft:endermite 11.5 64 1789.5 {Tags:["mg.mob"],PersistenceRequired:1b}
summon minecraft:endermite -11.5 64 1789.5 {Tags:["mg.mob"],PersistenceRequired:1b}
summon minecraft:endermite 0.5 64 1811.5 {Tags:["mg.mob"],PersistenceRequired:1b}
summon minecraft:endermite 0.5 64 1789.5 {Tags:["mg.mob"],PersistenceRequired:1b}
tellraw @a [{"text":"  ➜ ","color":"gray"},{"text":"2× Enderman, 4× Endermite","color":"yellow"},{"text":"  (6 monstres)","color":"dark_gray"}]
